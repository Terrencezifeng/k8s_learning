# K8s 当前计划

当前已经完成的目标是恢复这三台测试虚拟机上的 1 Master + 2 Worker 集群，并完成网络、DNS 和应用访问验收。接下来的学习建议从现有集群和 Nginx 示例展开。

## 已完成的工作

- [x] 建立 vm01、node1、node2 三个 SSH MCP 连接别名。
- [x] 检查 Kubernetes、kubelet、containerd、证书和网络状态。
- [x] 续签过期控制平面证书，恢复 API Server 和 etcd 之间的 TLS 通信。
- [x] 恢复 node1、node2 的 kubelet 客户端凭据和证书自动轮换。
- [x] 修正 containerd 默认 bridge CNI 与 Flannel 的配置冲突。
- [x] 补齐 Flannel CNI 初始化步骤，将 /run 挂载收窄到 /run/flannel。
- [x] 清除失效的 containerd 代理配置，调整启动等待时间。
- [x] 修复 Nginx 和 Dashboard 的镜像启动问题。
- [x] 完成验收并清理临时测试 Pod。
- [x] 生成中文 Debug 日志和原始修复记录。

## 修复验收标准与结果

| 验收项 | 结果 |
| --- | --- |
| 1 Master + 2 Worker | 全部 Ready |
| etcd 与 API Server | endpoint health 和 readyz 通过 |
| Flannel、kube-proxy | 分别 3/3 Ready |
| CoreDNS | 2/2 Ready |
| 跨节点 Pod 网络 | 6 个通信方向均通过，测试包无丢失 |
| 集群 DNS | 三个节点上的测试 Pod 均能解析集群服务 |
| Service HTTP | 三处测试均获得 Nginx 页面 |
| NodePort | 三个节点的 30255 端口均返回 HTTP 200 |
| Dashboard | 页面探测返回 HTTP 200 |
| 测试资源清理 | 临时命名空间已删除 |

完整证据见 [Debug 日志](logs/k8s-debug-20261028.log)。

## 后续学习建议

以下事项尚未执行。建议每次选择一个阶段，在独立实验命名空间内操作，结束后清理当次创建的资源。

| 阶段 | 学习内容 | 完成标志 |
| --- | --- | --- |
| 1 基础对象 | Node、Namespace、Pod、Deployment、标签与选择器；查看现有 Nginx | 能解释 Deployment、Pod、Service 之间的关系，并用 get、describe、logs 排查状态 |
| 2 部署与扩缩容 | 创建实验 Deployment，调整副本，观察调度、自愈和滚动更新 | 能完成一次部署、扩缩容和更新，并说明 Pod 的变化 |
| 3 网络访问 | Pod IP、ClusterIP、NodePort、DNS；观察两个 Worker 之间的通信 | 能验证 Pod、Service、NodePort 三种访问路径，并解释差别 |
| 4 配置与维护 | ConfigMap、Secret 基本使用、资源请求与限制、事件、日志和证书检查 | 能定位一次实验故障，并写出故障现象、证据、原因和处理结果 |

部署、观察、暴露服务、扩缩容和更新也是 Kubernetes 官方入门教程的主要练习顺序，可参考 [Learn Kubernetes Basics](https://kubernetes.io/docs/tutorials/kubernetes-basics/)。当前集群为 v1.22.2，使用文档示例前需要核对对应版本支持的 API 和字段。

## 维护事项

- [ ] 下次使用前重新检查节点、Pod、运行时和网络状态。
- [ ] 在需要升级时单独制定版本迁移计划，不在基础练习中顺带升级整个集群。
- [ ] 控制平面证书到期前检查并续签；本次新证书到期约为北京时间 2027-10-28。
- [ ] 如需长期运行，再规划备份、整机重启验收和资源扩容。

kubelet 自动轮换已恢复，控制平面证书的维护仍需单独安排。相关机制见 [kubeadm 证书管理](https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-certs/)。本项目没有配置新的定时任务。

## 本次范围

本次修复依据用户要求跳过了 etcd 和配置备份，没有重建集群或升级 Kubernetes。该选择属于本次测试环境修复记录；后续实验和维护按当次需求确定范围。
