# K8s 入门项目

这套 VMware 测试集群已于 2026 年 10 月 28 日完成修复，形成 1 个 Master 和 2 个 Worker。这个目录保存当前计划、集群交接资料和完整排障记录，供后续学习和运维继续使用。

| 节点 | IP | 角色 | 修复验收状态 |
| --- | --- | --- | --- |
| master | 192.168.169.3 | Master | Ready |
| node1 | 192.168.169.4 | Worker | Ready |
| node2 | 192.168.169.5 | Worker | Ready |

版本为 Kubernetes v1.22.2、containerd 1.5.5、Flannel v0.15.0。表中的状态是修复验收快照；每次实验开始时可按检查命令重新确认。

## 从这里开始

1. 阅读 [当前计划](PLAN.md)，区分已完成的修复与后续学习建议。
2. 阅读 [集群交接说明](docs/CLUSTER_CONTEXT.md)，了解连接方式、网络和已知限制。
3. 使用 [日常检查命令](docs/CHECK_COMMANDS.md) 查看集群状态。
4. 遇到问题时查阅 [中文 Debug 日志](logs/k8s-debug-20261028.log) 和 [原始修复记录](logs/k8s-repair-20261028.log)。

## 项目文件

| 文件 | 用途 |
| --- | --- |
| PLAN.md | 当前目标、完成项、验收标准和后续学习顺序 |
| docs/CLUSTER_CONTEXT.md | 节点、SSH MCP、网络、修复变更与交接上下文 |
| docs/CHECK_COMMANDS.md | 按执行位置划分的检查命令 |
| inventory/cluster.json | 可由程序读取的集群信息，不含登录凭据 |
| logs/k8s-debug-20261028.log | 中文根因分析、失败与重试、原始命令附录 |
| logs/k8s-repair-20261028.log | 修复阶段保存的原始执行记录 |
| PACKAGE-MANIFEST.json | 文件清单、大小和 SHA-256 校验值 |

## 已验证的访问入口

- [Nginx 测试服务](http://192.168.169.3:30255)
- [Kubernetes Dashboard](https://192.168.169.3:32320)

修复验收时，从 master 访问这两个入口均返回 HTTP 200。Dashboard 探测使用了自签名证书兼容方式；登录 Token 不包含在项目中。

## 在新的 Codex 对话中继续

可以直接发送：

> 请先阅读 README.md、PLAN.md 和 docs/CLUSTER_CONTEXT.md，通过现有 SSH MCP 只读检查三台机器，然后从 PLAN.md 中的基础对象学习开始，边操作边解释，Linux 编辑器默认使用 vim。

项目使用本机已有 SSH MCP。密钥仍位于原来的 Windows .ssh 目录，压缩包不携带私钥，也不会在另一台电脑上自动获得服务器访问权限。
